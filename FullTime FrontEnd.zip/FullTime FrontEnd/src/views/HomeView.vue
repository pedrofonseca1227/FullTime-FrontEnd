<script setup>

</script>

<template>
    <div class= "title">   
      <div class="row">
          <div class="col-sm-12 col-md-6">
              <h1>S.A.C <b>INTELIGENTE</b></h1>
          </div>
      </div>                 
    </div>
    <div class= "table-body">                   
      <div class="row">
          <div class="col-md-12">
              <table class="table table-striped table-hover">
                  <tbody> 
                     <tr>
                          <td>
                              <h2>Como podemos ajudar?</h2>
                              <input class="text" placeholder="SAC" type="text">
                          </td>
                              <h2><b>Fale Conosco</b></h2>
                          <td>
                              <div class="col-sm-12 col-md-6">
                                  <input class="btn btn-success" placeholder="SAC" type="submit">
                              </div>
                          </td>
                     </tr>
                  </tbody>
              </table>
          </div>
      </div>
    </div>  
</template>

